// Auto-generated. Do not edit!

// (in-package zzz_planning_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let nav_msgs = _finder('nav_msgs');

//-----------------------------------------------------------

class DecisionTrajectory {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.trajectory = null;
      this.desired_speed = null;
      this.desired_acc = null;
    }
    else {
      if (initObj.hasOwnProperty('trajectory')) {
        this.trajectory = initObj.trajectory
      }
      else {
        this.trajectory = new nav_msgs.msg.Path();
      }
      if (initObj.hasOwnProperty('desired_speed')) {
        this.desired_speed = initObj.desired_speed
      }
      else {
        this.desired_speed = 0.0;
      }
      if (initObj.hasOwnProperty('desired_acc')) {
        this.desired_acc = initObj.desired_acc
      }
      else {
        this.desired_acc = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DecisionTrajectory
    // Serialize message field [trajectory]
    bufferOffset = nav_msgs.msg.Path.serialize(obj.trajectory, buffer, bufferOffset);
    // Serialize message field [desired_speed]
    bufferOffset = _serializer.float32(obj.desired_speed, buffer, bufferOffset);
    // Serialize message field [desired_acc]
    bufferOffset = _serializer.float32(obj.desired_acc, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DecisionTrajectory
    let len;
    let data = new DecisionTrajectory(null);
    // Deserialize message field [trajectory]
    data.trajectory = nav_msgs.msg.Path.deserialize(buffer, bufferOffset);
    // Deserialize message field [desired_speed]
    data.desired_speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [desired_acc]
    data.desired_acc = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += nav_msgs.msg.Path.getMessageSize(object.trajectory);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'zzz_planning_msgs/DecisionTrajectory';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd07c52e707fc9c805fe4c0f8b804806a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    nav_msgs/Path trajectory
    
    float32 desired_speed # m/s
    
    float32 desired_acc # m^2/s
    ================================================================================
    MSG: nav_msgs/Path
    #An array of poses that represents a Path for a robot to follow
    Header header
    geometry_msgs/PoseStamped[] poses
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DecisionTrajectory(null);
    if (msg.trajectory !== undefined) {
      resolved.trajectory = nav_msgs.msg.Path.Resolve(msg.trajectory)
    }
    else {
      resolved.trajectory = new nav_msgs.msg.Path()
    }

    if (msg.desired_speed !== undefined) {
      resolved.desired_speed = msg.desired_speed;
    }
    else {
      resolved.desired_speed = 0.0
    }

    if (msg.desired_acc !== undefined) {
      resolved.desired_acc = msg.desired_acc;
    }
    else {
      resolved.desired_acc = 0.0
    }

    return resolved;
    }
};

module.exports = DecisionTrajectory;
