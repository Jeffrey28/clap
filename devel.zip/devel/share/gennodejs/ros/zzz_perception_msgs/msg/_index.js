
"use strict";

let Dimension2DWithCovariance = require('./Dimension2DWithCovariance.js');
let ObjectSignals = require('./ObjectSignals.js');
let LaneDetection = require('./LaneDetection.js');
let DimensionWithCovariance = require('./DimensionWithCovariance.js');
let DetectionBox = require('./DetectionBox.js');
let ObjectClass = require('./ObjectClass.js');
let DetectionBox2DArray = require('./DetectionBox2DArray.js');
let DetectionBox2D = require('./DetectionBox2D.js');
let LaneDetectionArray = require('./LaneDetectionArray.js');
let BoundingBox = require('./BoundingBox.js');
let TrackingBoxArray = require('./TrackingBoxArray.js');
let Pose2DWithCovariance = require('./Pose2DWithCovariance.js');
let BoundingBox2D = require('./BoundingBox2D.js');
let DetectionBoxArray = require('./DetectionBoxArray.js');
let TrackingBox = require('./TrackingBox.js');

module.exports = {
  Dimension2DWithCovariance: Dimension2DWithCovariance,
  ObjectSignals: ObjectSignals,
  LaneDetection: LaneDetection,
  DimensionWithCovariance: DimensionWithCovariance,
  DetectionBox: DetectionBox,
  ObjectClass: ObjectClass,
  DetectionBox2DArray: DetectionBox2DArray,
  DetectionBox2D: DetectionBox2D,
  LaneDetectionArray: LaneDetectionArray,
  BoundingBox: BoundingBox,
  TrackingBoxArray: TrackingBoxArray,
  Pose2DWithCovariance: Pose2DWithCovariance,
  BoundingBox2D: BoundingBox2D,
  DetectionBoxArray: DetectionBoxArray,
  TrackingBox: TrackingBox,
};
