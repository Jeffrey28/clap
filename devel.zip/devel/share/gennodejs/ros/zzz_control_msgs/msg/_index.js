
"use strict";

let AuxiliaryCommand = require('./AuxiliaryCommand.js');
let ControlCommand = require('./ControlCommand.js');

module.exports = {
  AuxiliaryCommand: AuxiliaryCommand,
  ControlCommand: ControlCommand,
};
