https://bitbucket.org/DataspeedInc/dbw_mkz_ros/src/default/


XXX_map_command: command value at a conversion map point
XXX_map_actuator: actuator value at a conversion map point
