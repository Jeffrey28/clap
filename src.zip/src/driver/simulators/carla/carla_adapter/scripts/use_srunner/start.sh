# This script is for Carla scenario_runner

. $ZZZ_ROOT/zzz/devel/setup.sh
roslaunch $ZZZ_ROOT/zzz/src/driver/simulators/carla/carla_adapter/scripts/use_srunner/main.launch # >zzz.log 2>zzz.err
