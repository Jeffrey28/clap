# KITTI Driver

This package is based on [pykitti](https://github.com/utiasSTARS/pykitti) @ [d3e1bb](https://github.com/utiasSTARS/pykitti/tree/d3e1bb81676e831886726cc5ed79ce1f049aef2c) and [kitti2bag](https://github.com/tomas789/kitti2bag) @ [75cd26](https://github.com/tomas789/kitti2bag/tree/75cd2629f23ac073a91384c4af1b88f3272c3b24)
