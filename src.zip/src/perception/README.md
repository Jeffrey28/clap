This module contains packages for sensor data processing.

# Detection box

The definition of detection is defined as follows (using vehicle as example):
- X axis is to the direction of vehicle longitudinal moving. Forward is the positive direction. The size in this direction is length.
- Y axis is to the direction of vehicle lateral moving. Right-side is the positive direction. The size in this direction is width.
- Z axis is to the vertical direction of vehicle. Up-side is the positive direction. The size in this direction is height.
