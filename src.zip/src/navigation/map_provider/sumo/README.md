This package provides interface to [SUMO](http://sumo.sourceforge.net/).

# Command

`netconvert --opendrive-files Town03.xodr --opendrive.import-all-lanes true --offset.disable-normalization true --opendrive.curve-resolution 0.5 -o map03_t.net.xml`
