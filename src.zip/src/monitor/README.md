This module should detect and deal with system failures. (Including perception failures, control failures, physical failures etc)
