'''
This packages contains tools for easier probability propagation

Reference
- https://mathoverflow.net/questions/35260/resultant-probability-distribution-when-taking-the-cosine-of-gaussian-distribute
'''
